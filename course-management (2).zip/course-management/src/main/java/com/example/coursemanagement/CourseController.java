package com.example.coursemanagement;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/courses")
public class CourseController {

    private List<Course> courses = new ArrayList<>();
    private Long idCounter = 1L;

    @PostMapping
    public Course addCourse(@RequestBody Course course) {
        course.setId(idCounter++);
        courses.add(course);
        return course;
    }

    @GetMapping
    public List<Course> getAllCourses() {
        return courses;
    }

    @PutMapping("/{id}")
    public Course updateCourse(@PathVariable Long id,
                               @RequestBody Course updatedCourse) {
        for (Course course : courses) {
            if (course.getId().equals(id)) {
                course.setCourseCode(updatedCourse.getCourseCode());
                course.setCourseName(updatedCourse.getCourseName());
                return course;
            }
        }
        return null;
    }

    @DeleteMapping("/{id}")
    public String deleteCourse(@PathVariable Long id) {
        courses.removeIf(course -> course.getId().equals(id));
        return "Course deleted successfully";
    }
}
